package ir.aut.ceit.app;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Program {
    private static int min = 100000000;
    private static float counter = 0;
    private static char[] cities;
    private static int n;

    private Program(int n) {
        Program.n = n;
        Program.cities = new char[Program.n];
    }

    private static void printAllKLength(char[] set, int n, int[][] city_city, int[][] city_month) {
        int k = set.length;
        int[][][] result = new int[k][k][n];
        for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) for (int vv = 0; vv < n; vv++) result[i][j][vv] = 0;
        printAllKLengthRec(set, "", k, n, n, city_city, city_month, result);
    }

    private static void printAllKLengthRec(char[] set, String prefix, int k, int n, int m, int[][] city_city, int[][] city_month, int[][][] result) {
        if (n == 0) {
            char[] parse = prefix.toCharArray();
            int cost = city_month[parse[0] - 48][0];
            int cnt = 0;
            for (int b = 1; b < m; b++) {
                int cnt2 = cnt + 1;
                int zz = parse[cnt2] - 48;
                int vv = parse[cnt] - 48;
                int bb = parse[cnt2] - 48;
                if (result[parse[cnt] - 48][parse[cnt2] - 48][b] == 0) {
                    int x = city_month[zz][b] + city_city[bb][vv];
                    result[parse[cnt] - 48][parse[cnt2] - 48][b] = x;
                    cost = cost + x;
                } else {
                    cost = cost + result[parse[cnt] - 48][parse[cnt2] - 48][b];
                }
                cnt = cnt2;
            }
            if (cost < min) {
                min = cost;
                System.arraycopy(parse, 0, cities, 0, cities.length);
            }
            if (counter == java.lang.Math.pow(k, m) - 1) {
                System.out.println("Cities order: ");
                int t=0;
                for (char city : cities) {
                    t++;
                    if(t!=cities.length)System.out.print(Character.getNumericValue(city) + 1 + " --> ");
                    else System.out.print(Character.getNumericValue(city) + 1 + " ");
                }
            }
            counter++;
            return;
        }
        for (int i = 0; i < k; ++i) {
            String newPrefix = prefix + set[i];
            printAllKLengthRec(set, newPrefix, k, n - 1, m, city_city, city_month, result);
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("src\\file.txt");
        Scanner sc = new Scanner(file);
        String fileContent;
        int months, cities;
        int[][] city_month;
        int[][] city_city;
        //read from file
        fileContent = sc.nextLine();
        months = Integer.parseInt(fileContent.split(" ")[1]);
        cities = Integer.parseInt(fileContent.split(" ")[0]);
        city_month = new int[cities][months];
        city_city = new int[cities][cities];

        for (int i = 0; i < cities; i++) {
            for (int j = 0; j < months; j++) {
                city_month[i][j] = Integer.parseInt(sc.next());
            }
        }
        for (int i = 0; i < cities; i++) {
            for (int j = 0; j < cities; j++) {
                if (i == j) {
                    city_city[i][i] = 0;
                    continue;
                }
                city_city[i][j] = Integer.parseInt(sc.next());
            }
        }
        char[] set = new char[cities];
        for (int i = 0; i < cities; i++) set[i] = String.valueOf(i).charAt(0);
        int n = months;
        new Program(n);
        printAllKLength(set, n, city_city, city_month);
        System.out.println(" ");
        System.out.println("Minimum cost:");
        System.out.println(min);
    }
}